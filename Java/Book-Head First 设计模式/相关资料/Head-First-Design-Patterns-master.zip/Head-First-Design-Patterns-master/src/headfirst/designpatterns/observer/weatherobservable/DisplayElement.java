package headfirst.designpatterns.observer.weatherobservable;

public interface DisplayElement {
	public void display();
}
