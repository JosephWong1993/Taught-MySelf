package headfirst.designpatterns.factory.pizzaaf;

public class BlackOlives implements Veggies {

	public String toString() {
		return "Black Olives";
	}
}
