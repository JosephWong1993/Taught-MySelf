package headfirst.designpatterns.combining.observer;

public interface Observer {
	public void update(QuackObservable duck);
}
