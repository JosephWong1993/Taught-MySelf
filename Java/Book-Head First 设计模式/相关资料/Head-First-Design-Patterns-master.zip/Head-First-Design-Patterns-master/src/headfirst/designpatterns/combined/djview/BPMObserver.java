package headfirst.designpatterns.combined.djview;
  
public interface BPMObserver {
	void updateBPM();
}
